import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		String username = req.getParameter("user");
		String password = req.getParameter("pass");
		
		
		if(username.equals("admin") && password.equals("admin123") || username.equals("user") && password.equals("user123")) {
			
			RequestDispatcher rd = req.getRequestDispatcher("/role");
			rd.forward(req, resp);
			
		}
		else {
			resp.setContentType("text/html");
			PrintWriter pw = resp.getWriter();
			pw.print("<body>");
			pw.print("<h3 style='color:red'>INCORRECT USERNAME OR PASSWORD</h3>");
			pw.print("</body>");
			RequestDispatcher rd = req.getRequestDispatcher("login.html");
			rd.include(req, resp);
			
			
		}
	}
	

}
