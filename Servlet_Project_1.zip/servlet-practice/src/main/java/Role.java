import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/role")
public class Role extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String username = req.getParameter("user");
		
		if(username.equals("admin")) {
			resp.sendRedirect("AdminDashboard.html");
			
		}
		else {
			resp.sendRedirect("UserDashboard.html");
		}
		PrintWriter pw = resp.getWriter();
		pw.print("You Have Successfully Logged In.");
		
	}

}
